# Research Journal Finder AI
Windows PowerShell Setup:
1. python -m venv venv
2. .\venv\Scripts\Activate.ps1
3. pip install -r requirements.txt
4. streamlit run app.py
