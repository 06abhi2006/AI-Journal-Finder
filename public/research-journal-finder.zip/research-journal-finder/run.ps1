# Windows PowerShell Launcher
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
