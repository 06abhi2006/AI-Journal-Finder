import streamlit as st
st.title("Research Journal Finder AI")
st.write("Autonomous AI Research Assistant")
